# Код успешной посылки 80320452
def in_place_quick_sort(data, left=0, right=None, priority=1, ascending=False):
    if right is None:
        right = len(data) - 1
    if right == left:
        return
    else:
        pivot_position = partition(data, left, right, priority, ascending)
        in_place_quick_sort(data, left, pivot_position, priority, ascending)
        in_place_quick_sort(data, pivot_position + 1, right, priority, ascending)


def partition(data, left, right, priority, ascending):
    pivot = data[(left + right) // 2][priority]
    while True:
        if ascending:
            while data[left][priority] < pivot:
                left += 1
            while data[right][priority] > pivot:
                right -= 1
        else:
            while data[left][priority] > pivot:
                left += 1
            while data[right][priority] < pivot:
                right -= 1
        if left >= right:
            return right
        data[left], data[right] = data[right], data[left]
        left += 1
        right -= 1


def read_input():
    total = int(input())
    data = [[]] * total
    for index in range(total):
        _input = input().split()
        data[index] = [_input[0], int(_input[1]), int(_input[2])]
    return total, data


if __name__ == '__main__':
    SCORES = 1
    PENALTIES = 2
    NAMES = 0
    total, data = read_input()
    in_place_quick_sort(data)
    start = None
    for index in range(1, len(data)):
        flag = data[index - 1][SCORES] == data[index][SCORES]
        if start is None and flag:
            start = index - 1
            end = index
        elif flag:
            end = index
        elif not flag and start is not None:
            in_place_quick_sort(
                data,
                left=start,
                right=end,
                priority=PENALTIES,
                ascending=True
            )
            start = None
    else:
        if start is not None:
            in_place_quick_sort(
                data,
                left=start,
                right=end,
                priority=PENALTIES,
                ascending=True
            )
    start = None
    for index in range(1, len(data)):
        flag = (
                data[index - 1][SCORES] == data[index][SCORES] and
                data[index - 1][PENALTIES] == data[index][PENALTIES]
        )

        if start is None and flag:
            start = index - 1
            end = index
        elif flag:
            end = index
        elif not flag and start is not None:
            in_place_quick_sort(
                data,
                left=start,
                right=end,
                priority=NAMES,
                ascending=True
            )
            start = None
    else:
        if start is not None:
            in_place_quick_sort(
                data,
                left=start,
                right=end,
                priority=NAMES,
                ascending=True
            )
    for item in data:
        print(item[NAMES])
